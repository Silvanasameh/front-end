const game = {
    team1: 'Bayern Munich',
    team2: 'Borrussia Dortmund',
    players: [
        [
            'Neuer','Pavard', 'Martinez','Alaba', 'Davies','Kimmich', 'Goretzka',   'Coman', 'Muller',  'Gnarby',  'Lewandowski',
        ],
        [
            'Burki','Schulz','Hummels','Akanji','Hakimi','Weigl','Witsel','Hazard','Brandt','Sancho','Gotze',
        ],
    ],
    score: '4:0',
    scored: ['Lewandowski', 'Gnarby', 'Lewandowski', 'Hummels'],
    date: 'Nov 9th, 2037',
    odds: {
        team1: 1.33,
        x: 3.25,
        team2: 6.5,
    },
};


const players1 = game.players[0];
const players2 = game.players[1];
const gk = players1[0];
const fieldPlayers = players1.slice(1);
const allPlayers = [...players1, ...players2];
const players1Final = [...players1, 'Thiago', 'Coutinho', 'Perisic'];
const team1 = game.odds.team1;
const draw = game.odds.x;
const team2 = game.odds.team2;
function printGoals(...players) {
    for (let i = 0; i < players.length; i++) {
        console.log(`Goal ${i + 1}: ${players[i]}`);
    }
    console.log(`Total goals: ${players.length}`);
}
printGoals('Davies', 'Muller', 'Lewandowski', 'Kimmich');
printGoals(...game.scored);
console.log(`Team ${team1 < team2 ? game.team1 : game.team2} is more likely to win`);
for (let i = 0; i < game.scored.length; i++) {
    console.log(`Goal ${i + 1}: ${game.scored[i]}`);
}
let sumOdds = 0;
for (const odd in game.odds) {
    sumOdds += game.odds[odd];
}
const averageOdd = sumOdds / Object.keys(game.odds).length;
console.log(`Average odd: ${averageOdd}`);
console.log(`Odd of victory ${game.team1}: ${team1}`);
console.log(`Odd of draw: ${draw}`);
console.log(`Odd of victory ${game.team2}: ${team2}`);
const scorers = {};
for (const player of game.scored) {
    if (scorers[player]) {
        scorers[player]++;
    } else {
        scorers[player] = 1;
    }
}
console.log(scorers);
